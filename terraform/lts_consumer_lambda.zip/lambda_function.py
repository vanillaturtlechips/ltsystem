import base64
import json
import boto3
import os
import datetime

S3_BUCKET_NAME = os.environ['S3_BUCKET_NAME']
DYNAMO_TABLE_NAME = os.environ['DYNAMO_TABLE_NAME']

s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
dynamo_table = dynamodb.Table(DYNAMO_TABLE_NAME)

print('Loading function')

def lambda_handler(event, context):
    print(f"Received {len(event['Records'])} records.")
        
    processed_records = 0
        
    for record in event['Records']:
        payload = None
        try:
            payload = base64.b64decode(record['kinesis']['data']).decode('utf-8')
                
            print(f"--- RAW PAYLOAD RECEIVED ---")
            print(f"Type: {type(payload)}")
            print(f"Payload: {payload}")
            print(f"--- END RAW PAYLOAD ---")

            data = json.loads(payload) 
            vehicle_id = data['VehicleID']

            now = datetime.datetime.now()
            s3_key = f"year={now.year}/month={now.month:02d}/day={now.day:02d}/{vehicle_id}-{now.timestamp()}.json"
                
            s3_client.put_object(
                Bucket=S3_BUCKET_NAME,
                Key=s3_key,
                Body=payload
            )

            dynamo_table.put_item(
                Item=data
            )
                
            print(f"Successfully processed and stored data for VehicleID: {vehicle_id}")
            processed_records += 1
                
        except Exception as e:
            print(f"!!! ERROR processing record !!!")
            print(f"Error: {e}")
            print(f"--- FAILED PAYLOAD ---")
            print(f"Type: {type(payload)}")
            print(f"Payload: {payload}")
            print(f"--- END FAILED PAYLOAD ---")

    return f"Successfully processed {processed_records} records."
